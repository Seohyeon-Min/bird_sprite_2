#include <iostream>


#ifndef beat_system_H
#define beat_system_H

void IsOnBeat();
extern bool judge;

#endif
