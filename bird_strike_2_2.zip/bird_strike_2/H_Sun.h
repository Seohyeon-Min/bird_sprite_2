#include <iostream>

#ifndef SUN_H
#define SUN_H

bool _sun();
float drop_v(float i);
void draw_sun(float sun_y);

#endif