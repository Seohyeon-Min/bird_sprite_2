#ifndef MOUSE_H
#define MOUSE_H

void mouse_control();

#endif